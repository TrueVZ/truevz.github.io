def unique_elements(lst):
    """
    Number of unique elements.
    TODO add 3 meaningful examples in doctest format
    """
    return lst


import doctest
doctest.testmod()
