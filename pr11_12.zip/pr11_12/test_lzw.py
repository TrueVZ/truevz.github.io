from hypothesis import given
import hypothesis.strategies as st
import lzw


# TODO
#@given(...)
def test_property(x):
    pass


test_property()
