import sys
import inspect
import random
import calc


def coverage(f):
    lines = set()
    def trace(frame, event, arg):
        lines.add((event, frame.f_lineno))
        return trace
    sys.settrace(trace)
    f()
    sys.settrace(None)
    return lines


def print_coverage(module, trace):
    lines = [y for x, y in trace]
    source = inspect.getsource(module).splitlines()
    for i, x in enumerate(source):
        print(("|" if i + 1 in lines else " ") + x)


def test_calc(s):
    try:
        return calc.calc(s)
    except:
        pass


def tests():
    test_calc("2 + 2")


c = coverage(tests)
#print_coverage(calc, c)
print(len(c))
